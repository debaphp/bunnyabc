/* Bunny ABC — single-page app running inside the Android WebView.
   Bridges (optional, injected by MainActivity): AndroidTts, AppBridge. In a desktop browser it falls back to speechSynthesis. */
'use strict';

/* ---------- storage ---------- */
var KEY = 'bunnyabc.v1';
var DEF_SET = { lang: 'en', speed: 1.0, sfx: true, opts: 4, range: 'all', kase: 'both', auto: true, limit: 0 };
var S = load();
function load() {
  var s = null;
  try { s = JSON.parse(localStorage.getItem(KEY)); } catch (e) {}
  if (!s || typeof s !== 'object') s = {};
  s.stars = s.stars || 0;
  s.L = s.L || {};
  s.set = Object.assign({}, DEF_SET, s.set || {});
  s.day = s.day || { d: '', secs: 0 };
  if (!s.set.langChosen) {          // first run: Bengali UI for BD / IN-Bengali phones
    var bn = false;
    try { bn = window.AppBridge && AppBridge.country && ['BD'].indexOf(AppBridge.country()) >= 0; } catch (e) {}
    if (!bn) bn = /^bn/i.test(navigator.language || '');
    s.set.lang = bn ? 'bn' : 'en'; s.set.langChosen = true;
  }
  return s;
}
function save() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} }
function stat(L) { return S.L[L] || (S.L[L] = { w: 0, t: 0, qc: 0, qt: 0 }); }
function T(k) { return (STR[S.set.lang] && STR[S.set.lang][k]) || STR.en[k] || k; }

/* ---------- helpers ---------- */
var app = document.getElementById('app');
function $(sel) { return app.querySelector(sel); }
function $$(sel) { return Array.prototype.slice.call(app.querySelectorAll(sel)); }
function em(code, cls) { return '<img class="' + (cls || 'e') + '" src="img/e/' + code + '.svg" alt="">'; }
function idx(L) { return L.charCodeAt(0) - 65; }
function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
function pick(a) { return a[Math.floor(Math.random() * a.length)]; }
function disp(L) { var k = S.set.kase; return k === 'upper' ? L : k === 'lower' ? L.toLowerCase() : L + L.toLowerCase(); }
function startWords(d) { return d.words.filter(function (w) { return !w.end; }); }
function sentence(d) {
  return d.L + '. ' + d.words.map(function (w) { return w.end ? w.w + ' ends with ' + d.L : d.L + ' for ' + w.w; }).join('. ') + '.';
}

/* ---------- voice ---------- */
function say(text) {
  try {
    if (window.AndroidTts) { AndroidTts.speak(text, S.set.speed); return; }
    if (window.speechSynthesis) {
      speechSynthesis.cancel();
      var u = new SpeechSynthesisUtterance(text); u.lang = 'en-US'; u.rate = 0.9 * S.set.speed; u.pitch = 1.1;
      speechSynthesis.speak(u);
    }
  } catch (e) {}
}
function hush() { try { if (window.AndroidTts) AndroidTts.stop(); else if (window.speechSynthesis) speechSynthesis.cancel(); } catch (e) {} }

/* ---------- sound effects (generated, no files) ---------- */
var AC = null;
function tone(freqs, dur, type) {
  if (!S.set.sfx) return;
  try {
    AC = AC || new (window.AudioContext || window.webkitAudioContext)();
    var t = AC.currentTime;
    freqs.forEach(function (f, i) {
      var o = AC.createOscillator(), g = AC.createGain();
      o.type = type || 'sine'; o.frequency.value = f;
      g.gain.setValueAtTime(0.0001, t + i * dur); g.gain.exponentialRampToValueAtTime(0.25, t + i * dur + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t + (i + 1) * dur + 0.1);
      o.connect(g); g.connect(AC.destination); o.start(t + i * dur); o.stop(t + (i + 1) * dur + 0.12);
    });
  } catch (e) {}
}
function sfxGood() { tone([523, 659, 784, 1047], 0.09); }
function sfxBad() { tone([220, 180], 0.14, 'triangle'); }
function sfxTap() { tone([660], 0.05); }
function buzz(ms) { try { if (window.AppBridge && AppBridge.vibrate) AppBridge.vibrate(ms); } catch (e) {} }

function confetti(n) {
  var fx = document.getElementById('fx'), cols = ['#ff6b5b', '#ffc93c', '#2e9d4f', '#1e88e5', '#e2427b'];
  for (var i = 0; i < (n || 40); i++) {
    var c = document.createElement('i'); c.className = 'conf';
    c.style.left = Math.random() * 100 + 'vw'; c.style.top = (-10 - Math.random() * 30) + 'px';
    c.style.background = pick(cols); c.style.animationDelay = Math.random() * 0.3 + 's';
    fx.appendChild(c); setTimeout(function (el) { el.remove(); }.bind(null, c), 1900);
  }
}
function toast(msg) { var d = document.createElement('div'); d.className = 'toast'; d.textContent = msg; document.body.appendChild(d); setTimeout(function () { d.remove(); }, 1800); }

/* ---------- router ---------- */
var cur = { name: 'home', arg: null }, timers = [];
function later(fn, ms) { timers.push(setTimeout(fn, ms)); }
function clearTimers() { timers.forEach(clearTimeout); timers = []; }
function go(name, arg) {
  clearTimers(); hush();
  var v = app.querySelector('video'); if (v) { v.pause(); v.removeAttribute('src'); v.load(); }
  if (name !== 'parents' && name !== 'gate' && overLimit()) name = 'sleepy';
  cur = { name: name, arg: arg };
  app.scrollTop = 0;
  (SCREENS[name] || SCREENS.home)(arg);
}
// Android back button -> MainActivity calls window.onBack(); return 'exit' to close the app
window.onBack = function () {
  if (cur.name === 'home') return 'exit';
  if (cur.name === 'letter' || cur.name === 'trace') go(cur.arg && cur.arg.from === 'home' ? 'home' : 'grid');
  else if (cur.name === 'quiz') go('quizMenu');
  else go('home');
  return 'ok';
};
function topBar(title, backTo) {
  return '<div class="bar"><button class="icon-btn" data-go="' + (backTo || 'home') + '" aria-label="back">' + em('1f3e0') + '</button>' +
    '<h2>' + title + '</h2><div class="stars">' + em('2b50') + '<span id="starN">' + S.stars + '</span></div></div>';
}
function wireGo() { $$('[data-go]').forEach(function (b) { b.onclick = function () { sfxTap(); go(b.getAttribute('data-go')); }; }); }
function addStar(n) { S.stars += n || 1; save(); var s = document.getElementById('starN'); if (s) s.textContent = S.stars; }

/* ---------- daily time limit ---------- */
function today() { var d = new Date(); return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate(); }
function overLimit() { if (!S.set.limit) return false; if (S.day.d !== today()) return false; return S.day.secs >= S.set.limit * 60; }
setInterval(function () {
  if (document.hidden) return;
  if (S.day.d !== today()) S.day = { d: today(), secs: 0 };
  S.day.secs += 10; save();
  if (overLimit() && ['parents', 'gate', 'sleepy'].indexOf(cur.name) < 0) go('sleepy');
}, 10000);

/* ---------- screens ---------- */
var SCREENS = {};

SCREENS.home = function () {
  app.innerHTML = '<section class="screen">' +
    '<div class="bar"><h1>' + T('title') + '</h1><div class="stars">' + em('2b50') + '<span id="starN">' + S.stars + '</span></div></div>' +
    '<div class="hero"><img class="bunny" src="img/bunny.webp" alt=""><div class="bubble" id="hi">' + T('hello') + '</div></div>' +
    '<div class="menu">' +
      '<button class="btn b-learn" data-go="grid">' + em('1f34e') + T('learn') + '</button>' +
      '<button class="btn b-quiz" data-go="quizMenu">' + em('1f9e9') + T('quiz') + '</button>' +
      '<button class="btn b-trace" id="goTrace">' + em('270f') + T('trace') + '</button>' +
      '<button class="btn b-watch" id="watchAll">' + em('1f3ac') + T('watchAll') + '</button>' +
    '</div>' +
    '<button class="parents-hold" id="ph"><div class="fill"></div><span>' + em('1f468-200d-1f469-200d-1f467') + ' ' + T('parents') + ' · ' + T('hold') + '</span></button>' +
    '</section>';
  wireGo();
  $('#goTrace').onclick = function () { sfxTap(); go('trace', { i: firstUntraced(), from: 'home' }); };
  $('#watchAll').onclick = function () { sfxTap(); go('letter', { i: 0, all: true, from: 'home' }); };
  holdButton($('#ph'), 2000, function () { go('gate'); });
  if (!SCREENS.home.greeted) { SCREENS.home.greeted = true; later(function () { say("Hello! I'm your Bunny teacher. Let's learn A B C!"); }, 600); }
};

function holdButton(el, ms, done) {
  var t = null;
  function start(e) { e.preventDefault(); el.classList.add('holding'); t = setTimeout(function () { el.classList.remove('holding'); buzz(40); done(); }, ms); }
  function stop() { el.classList.remove('holding'); clearTimeout(t); }
  el.addEventListener('touchstart', start, { passive: false }); el.addEventListener('mousedown', start);
  ['touchend', 'touchcancel', 'mouseup', 'mouseleave'].forEach(function (ev) { el.addEventListener(ev, stop); });
}
function firstUntraced() { for (var i = 0; i < 26; i++) if (!stat(LETTERS[i].L).t) return i; return 0; }

SCREENS.grid = function () {
  var h = '<section class="screen">' + topBar(T('learn')) + '<div class="grid">';
  LETTERS.forEach(function (d, i) {
    var s = stat(d.L);
    h += '<button class="tile" data-i="' + i + '" style="border-color:' + d.color + '">' +
      (d.video ? '<img class="poster" src="img/poster/' + d.L.toLowerCase() + '.webp" alt="" loading="lazy">' : '') +
      (s.w ? em('2705', 'done') : '') +
      '<span class="big">' + disp(d.L) + '</span>' +
      '<span class="pics">' + d.words.map(function (w) { return em(w.e); }).join('') + '</span>' +
      (d.video ? '<span class="play">▶</span>' : '') + '</button>';
  });
  app.innerHTML = h + '</div></section>';
  wireGo();
  $$('.tile').forEach(function (b) { b.onclick = function () { sfxTap(); go('letter', { i: +b.getAttribute('data-i') }); }; });
};

SCREENS.letter = function (arg) {
  var i = arg.i, d = LETTERS[i], l = d.L.toLowerCase();
  var stage = d.video
    ? '<video id="vid" playsinline preload="auto" poster="img/poster/' + l + '.webp" src="video/' + l + '.mp4"></video>' +
      '<button class="playover" id="po"><b>▶</b></button>'
    : '<div class="chalkcard"><img class="bunny-s" src="img/bunny.webp" alt=""><div class="txt">' +
      '<div class="bigL" id="cL">' + d.L + d.L.toLowerCase() + '</div>' +
      d.words.map(function (w, k) { return '<div class="line" id="cw' + k + '">' + em(w.e) + (w.end ? w.w + ' (…' + d.L.toLowerCase() + ')' : d.L + ' for ' + w.w) + '</div>'; }).join('') +
      '</div></div><div class="soon">' + T('soon') + '</div><button class="playover" id="po" style="background:none"></button>';
  var words = '<div class="words">' + d.words.map(function (w) {
    var first = w.end ? w.w : '<span class="first" style="color:' + d.color + '">' + w.w.charAt(0) + '</span>' + w.w.slice(1);
    if (w.end) first = w.w.slice(0, -1) + '<span class="first" style="color:' + d.color + '">' + w.w.slice(-1) + '</span>';
    return '<button class="word" data-w="' + w.w + '">' + em(w.e) + '<span>' + first + '</span></button>';
  }).join('') + '</div>';
  app.innerHTML = '<section class="screen">' + topBar(T('letter') + ' ' + disp(d.L), arg.from === 'home' ? 'home' : 'grid') +
    '<div class="letter-layout"><div class="stage">' + stage + '</div>' + words + '</div>' +
    '<div class="nav">' +
      '<button class="btn b-plain" id="prev"' + (i === 0 ? ' disabled style="opacity:.4"' : '') + '>◀</button>' +
      '<button class="btn b-trace" id="tr">' + em('270f') + '</button>' +
      '<button class="btn b-plain" id="next"' + (i === 25 ? ' disabled style="opacity:.4"' : '') + '>▶</button>' +
    '</div></section>';
  wireGo();
  var all = !!arg.all, from = arg.from;
  $('#prev').onclick = function () { if (i > 0) go('letter', { i: i - 1, all: all, from: from }); };
  $('#next').onclick = function () { if (i < 25) go('letter', { i: i + 1, all: all, from: from }); };
  $('#tr').onclick = function () { go('trace', { i: i, from: from }); };
  $$('.word').forEach(function (b) { b.onclick = function () { b.style.transform = 'scale(1.05)'; setTimeout(function () { b.style.transform = ''; }, 200); say(b.getAttribute('data-w')); }; });

  function finished() {
    var s = stat(d.L); s.w++; save();
    if (s.w === 1) { addStar(1); confetti(20); }
    if ((all || S.set.auto) && i < 25 && (all || d.video)) later(function () { go('letter', { i: i + 1, all: all, from: from }); }, all ? 1200 : 2500);
  }
  if (d.video) {
    var v = $('#vid'), po = $('#po');
    function play() { po.style.display = 'none'; v.currentTime = 0; var p = v.play(); if (p && p.catch) p.catch(function () { po.style.display = ''; }); }
    po.onclick = play; v.onclick = function () { if (v.paused) play(); else v.pause(); };
    v.onended = function () { po.style.display = ''; po.firstChild.textContent = '↻'; finished(); };
    later(play, 350);
  } else {
    function card() {
      ['cL', 'cw0', 'cw1'].forEach(function (id) { var e = document.getElementById(id); e.classList.remove('show'); void e.offsetWidth; });
      say(sentence(d));
      document.getElementById('cL').classList.add('show');
      later(function () { document.getElementById('cw0').classList.add('show'); }, 1300);
      later(function () { document.getElementById('cw1').classList.add('show'); }, 2900);
      later(finished, 4600);
    }
    $('#po').onclick = function () { clearTimers(); card(); };
    later(card, 350);
  }
};

/* ---------- quiz ---------- */
var QTYPES = [
  { k: 'listen', c: '#1e88e5', ic: function () { return em('1f442'); } },
  { k: 'starts', c: '#ff6b5b', ic: function () { return em('1f34e'); } },
  { k: 'picture', c: '#2e9d4f', ic: function () { return em('1f436'); } },
  { k: 'case', c: '#8e24aa', ic: function () { return 'Aa'; } },
  { k: 'missing', c: '#fb8c00', ic: function () { return 'A_C'; } },
  { k: 'mix', c: '#e2427b', ic: function () { return em('1f389'); } }
];
SCREENS.quizMenu = function () {
  app.innerHTML = '<section class="screen">' + topBar(T('chooseGame')) + '<div class="qmenu">' +
    QTYPES.map(function (q) {
      return '<button class="qcard" data-q="' + q.k + '"><div class="ic" style="background:' + q.c + '">' + q.ic() + '</div><b>' + T('q_' + q.k) + '</b><small>' + T('q_' + q.k + '_d') + '</small></button>';
    }).join('') + '</div></section>';
  wireGo();
  $$('.qcard').forEach(function (b) { b.onclick = function () { sfxTap(); go('quiz', { type: b.getAttribute('data-q') }); }; });
  later(function () { say('Choose a game!'); }, 300);
};

function quizPool(onlyLetters) {
  var r = S.set.range, pool;
  if (onlyLetters) pool = onlyLetters.slice();
  else if (r === 'ae') pool = LETTERS.slice(0, 5);
  else if (r === 'am') pool = LETTERS.slice(0, 13);
  else if (r === 'learned') { pool = LETTERS.filter(function (d) { return stat(d.L).w > 0; }); if (pool.length < 3) pool = LETTERS.slice(0, 5); }
  else pool = LETTERS.slice();
  return pool;
}
function distractors(ans, n, from) {
  var others = shuffle(from.filter(function (x) { return x !== ans; }));
  if (others.length < n) others = others.concat(shuffle(LETTERS.filter(function (x) { return x !== ans && others.indexOf(x) < 0; })));
  return others.slice(0, n);
}
function makeQ(type, pool) {
  if (type === 'mix') type = pick(['listen', 'starts', 'picture', 'case', 'missing']);
  var n = S.set.opts, d = pick(pool), q = { type: type, d: d };
  var opts = shuffle([d].concat(distractors(d, n - 1, pool)));
  if (type === 'listen') {
    q.speak = 'Find the letter ' + d.L + '!';
    q.html = '<button class="say" id="again">' + em('1f50a') + ' ' + T('q_listen') + '</button><div class="huge">?</div>';
    q.opts = opts.map(function (o) { return { ok: o === d, L: o.L, html: disp(o.L) }; });
  } else if (type === 'starts') {
    var w = pick(startWords(d)); q.word = w.w;
    q.speak = w.w + '. ' + w.w + ' starts with which letter?';
    q.html = '<img class="pic" src="img/e/' + w.e + '.svg" alt=""><div class="hint">?' + w.w.slice(1).toLowerCase() + '</div>';
    q.opts = opts.map(function (o) { return { ok: o === d, L: o.L, html: disp(o.L) }; });
    q.praise = w.w + ' starts with ' + d.L + '!';
  } else if (type === 'picture') {
    q.speak = 'Which picture starts with ' + d.L + '?';
    q.html = '<button class="say" id="again">' + em('1f50a') + '</button><div class="huge">' + disp(d.L) + '</div>';
    q.opts = opts.map(function (o) { var w = pick(startWords(o)); return { ok: o === d, L: o.L, word: w.w, html: em(w.e) }; });
  } else if (type === 'case') {
    var up = Math.random() < 0.5;
    q.speak = up ? 'Find the small letter ' + d.L + '.' : 'Find the big letter ' + d.L + '.';
    q.html = '<button class="say" id="again">' + em('1f50a') + '</button><div class="huge">' + (up ? d.L : d.L.toLowerCase()) + '</div>';
    q.opts = opts.map(function (o) { return { ok: o === d, L: o.L, html: up ? o.L.toLowerCase() : o.L }; });
  } else { // missing
    var i = idx(d.L); if (i === 0) i = 1; if (i === 25) i = 24; d = LETTERS[i]; q.d = d;
    var hole = pick([0, 1, 2]), seq = [LETTERS[i - 1], d, LETTERS[i + 1]], ans = seq[hole];
    q.d = ans;
    var near = LETTERS.slice(Math.max(0, i - 4), Math.min(26, i + 5));
    var o2 = shuffle([ans].concat(distractors(ans, n - 1, near)));
    q.speak = 'Which letter is missing?';
    var low = S.set.kase === 'lower';
    q.html = '<button class="say" id="again">' + em('1f50a') + '</button><div class="seq">' +
      seq.map(function (x, k) { return k === hole ? '<span class="q">?</span>' : '<span>' + (low ? x.L.toLowerCase() : x.L) + '</span>'; }).join('') + '</div>';
    q.opts = o2.map(function (o) { return { ok: o === ans, L: o.L, html: low ? o.L.toLowerCase() : o.L }; });
  }
  q.praise = q.praise || (pick(['Great!', 'Super!', 'Well done!', 'Yes!', 'Wonderful!']) + ' ' + q.d.L + ' for ' + startWords(q.d)[0].w + '!');
  return q;
}

SCREENS.quiz = function (arg) {
  var N = 10, k = 0, score = 0, pool = quizPool(arg.only), lastL = null;
  function next() {
    if (k >= N) return result();
    var q, tries = 0;
    do { q = makeQ(arg.type, pool); tries++; } while (q.d.L === lastL && tries < 6);
    lastL = q.d.L;
    var firstTry = true;
    app.innerHTML = '<section class="screen">' + topBar(T('q_' + arg.type), 'quizMenu') +
      '<div class="progress"><i style="width:' + (k / N * 100) + '%"></i></div>' +
      '<div class="prompt">' + q.html + '</div>' +
      '<div class="opts' + (q.opts.length === 3 ? ' n3' : '') + '">' +
      q.opts.map(function (o, j) { return '<button class="opt" data-j="' + j + '">' + o.html + '</button>'; }).join('') + '</div></section>';
    wireGo();
    var again = $('#again'); if (again) again.onclick = function () { say(q.speak); };
    var pic = $('.prompt .pic'); if (pic) pic.onclick = function () { say(q.speak); };
    later(function () { say(q.speak); }, 250);
    var locked = false;
    $$('.opt').forEach(function (b) {
      b.onclick = function () {
        if (locked || b.classList.contains('wrong')) return;
        var o = q.opts[+b.getAttribute('data-j')], s = stat(q.d.L);
        if (o.ok) {
          locked = true; b.classList.add('right'); sfxGood(); confetti(18); buzz(20);
          if (firstTry) { score++; s.qc++; addStar(1); }
          s.qt++; save();
          say(q.praise); k++;
          later(next, 1700);
        } else {
          if (firstTry) { firstTry = false; }
          b.classList.add('wrong'); sfxBad(); buzz(60);
          say(o.word ? o.word + ' starts with ' + o.L + '. Try again!' : 'Try again!');
        }
      };
    });
  }
  function result() {
    var medals = score >= 9 ? 3 : score >= 6 ? 2 : score >= 3 ? 1 : 0;
    app.innerHTML = '<section class="screen"><div class="result"><img class="bunny" src="img/bunny.webp" alt="">' +
      '<h2>' + (medals >= 2 ? T('great') : T('wellDone')) + '</h2>' +
      '<div class="medal">' + [0, 1, 2].map(function (m) { return em('2b50', m < medals ? '' : 'dim'); }).join('') + '</div>' +
      '<p>' + T('youGot') + ' <b>' + score + '</b> / ' + N + '</p>' +
      '<div class="row"><button class="btn b-quiz" id="pa">' + T('playAgain') + '</button><button class="btn b-plain" data-go="quizMenu">' + T('back') + '</button></div></div></section>';
    wireGo(); confetti(70); tone([523, 659, 784, 659, 784, 1047], 0.12);
    say(score >= 6 ? 'Hooray! You got ' + score + ' out of ' + N + '!' : 'Good try! You got ' + score + '. Let\'s play again!');
    $('#pa').onclick = function () { go('quiz', arg); };
  }
  next();
};

/* ---------- tracing ---------- */
SCREENS.trace = function (arg) {
  var i = arg.i, d = LETTERS[i], lower = !!arg.lower, ch = lower ? d.L.toLowerCase() : d.L;
  app.innerHTML = '<section class="screen">' + topBar(T('trace') + ' ' + disp(d.L), arg.from === 'home' ? 'home' : 'grid') +
    '<p class="trace-hint">' + T('traceHint') + '</p>' +
    '<div class="trace-wrap"><canvas id="guide"></canvas><canvas id="ink"></canvas></div>' +
    '<div class="trace-tools"><button class="btn b-plain" id="tp">◀</button>' +
    '<div class="seg"><button id="up" class="' + (lower ? '' : 'on') + '">' + d.L + '</button><button id="lo" class="' + (lower ? 'on' : '') + '">' + d.L.toLowerCase() + '</button></div>' +
    '<button class="btn b-plain" id="clr">' + T('clear') + '</button><button class="btn b-plain" id="tn">▶</button></div></section>';
  wireGo();
  var from = arg.from;
  $('#tp').onclick = function () { go('trace', { i: (i + 25) % 26, lower: lower, from: from }); };
  $('#tn').onclick = function () { go('trace', { i: (i + 1) % 26, lower: lower, from: from }); };
  $('#up').onclick = function () { go('trace', { i: i, lower: false, from: from }); };
  $('#lo').onclick = function () { go('trace', { i: i, lower: true, from: from }); };

  var G = $('#guide'), I = $('#ink'), wrap = $('.trace-wrap'), dpr = Math.min(window.devicePixelRatio || 1, 2);
  var W, H, gx, ix, mask = null, samples = [], done = false, lw;
  function setup() {
    W = wrap.clientWidth; H = wrap.clientHeight;
    [G, I].forEach(function (c) { c.width = W * dpr; c.height = H * dpr; });
    gx = G.getContext('2d'); ix = I.getContext('2d'); gx.scale(dpr, dpr); ix.scale(dpr, dpr);
    var fs = Math.min(H * (lower ? 0.78 : 0.86), W * (lower ? 1.15 : 1.0));
    lw = Math.max(18, fs * 0.11);
    var font = '700 ' + fs + 'px Fredoka', y = H / 2 + fs * (lower ? 0.18 : 0.02);
    // guide: faint fill + dotted outline
    gx.font = font; gx.textAlign = 'center'; gx.textBaseline = 'middle';
    gx.fillStyle = 'rgba(255,255,255,.13)'; gx.fillText(ch, W / 2, y);
    gx.setLineDash([2, 12]); gx.lineCap = 'round'; gx.lineWidth = Math.max(5, fs * 0.012); gx.strokeStyle = 'rgba(255,255,255,.9)'; gx.strokeText(ch, W / 2, y);
    // hidden mask for checking coverage
    var m = document.createElement('canvas'); m.width = W; m.height = H; var mx = m.getContext('2d');
    mx.font = font; mx.textAlign = 'center'; mx.textBaseline = 'middle'; mx.fillStyle = '#000'; mx.fillText(ch, W / 2, y);
    var px = mx.getImageData(0, 0, W, H).data; samples = [];
    var step = Math.max(6, Math.round(fs / 40));
    for (var yy = 0; yy < H; yy += step) for (var xx = 0; xx < W; xx += step) if (px[(yy * W + xx) * 4 + 3] > 128) samples.push([xx, yy]);
    mask = px;
    ix.lineCap = 'round'; ix.lineJoin = 'round'; ix.lineWidth = lw; ix.strokeStyle = d.color === '#212121' ? '#ffc93c' : d.color;
    ix.shadowColor = 'rgba(255,255,255,.6)'; ix.shadowBlur = 4;
  }
  document.fonts && document.fonts.load('700 100px Fredoka').then(setup, setup) || setup();

  var drawing = false, last = null, inkIn = 0, inkOut = 0;
  function pos(e) { var r = I.getBoundingClientRect(), t = e.touches ? e.touches[0] : e; return [t.clientX - r.left, t.clientY - r.top]; }
  function down(e) { e.preventDefault(); if (done) return; drawing = true; last = pos(e); dot(last); }
  function dot(p) { ix.beginPath(); ix.arc(p[0], p[1], lw / 2, 0, 7); ix.fillStyle = ix.strokeStyle; ix.fill(); count(p); }
  function count(p) { var x = Math.round(p[0]), y = Math.round(p[1]); if (x < 0 || y < 0 || x >= W || y >= H) return; if (mask[(y * W + x) * 4 + 3] > 128) inkIn++; else inkOut++; }
  function move(e) { if (!drawing) return; e.preventDefault(); var p = pos(e); ix.beginPath(); ix.moveTo(last[0], last[1]); ix.lineTo(p[0], p[1]); ix.stroke(); count(p); last = p; }
  function up() { if (!drawing) return; drawing = false; check(); }
  function check() {
    if (done || !samples.length) return;
    var cw = I.width, ch2 = I.height, data = ix.getImageData(0, 0, cw, ch2).data, hit = 0, sx = cw / W, sy = ch2 / H;
    samples.forEach(function (s) { var x = Math.min(cw - 1, Math.round(s[0] * sx)), y = Math.min(ch2 - 1, Math.round(s[1] * sy)); if (data[(y * cw + x) * 4 + 3] > 60) hit++; });
    var cover = hit / samples.length, messy = inkOut / Math.max(1, inkIn + inkOut);
    if (cover > 0.72 && messy < 0.45) {
      done = true; var s = stat(d.L); s.t++; save(); if (s.t === 1) addStar(2); else addStar(1);
      sfxGood(); confetti(60); say(pick(['Beautiful!', 'Well done!', 'Super writing!']) + ' ' + d.L + ' for ' + startWords(d)[0].w + '!');
      later(function () { go('trace', { i: lower ? (i + 1) % 26 : i, lower: !lower, from: from }); }, 2600);
    }
  }
  I.addEventListener('touchstart', down, { passive: false }); I.addEventListener('touchmove', move, { passive: false }); I.addEventListener('touchend', up);
  I.addEventListener('mousedown', down); I.addEventListener('mousemove', move); window.addEventListener('mouseup', up);
  $('#clr').onclick = function () { ix.clearRect(0, 0, W, H); inkIn = inkOut = 0; done = false; };
  later(function () { say('Trace the ' + (lower ? 'small' : 'big') + ' letter ' + d.L + '.'); }, 300);
};

/* ---------- parents gate + area ---------- */
SCREENS.gate = function () {
  var a = 3 + Math.floor(Math.random() * 7), b = 4 + Math.floor(Math.random() * 6), ans = '';
  app.innerHTML = '<section class="screen">' + topBar(T('parents')) + '<div class="gate">' +
    '<p>' + T('gateQ') + '</p><div class="q">' + a + ' × ' + b + ' = ?</div><div class="ans" id="ans"></div>' +
    '<div class="pad">' + [1, 2, 3, 4, 5, 6, 7, 8, 9, '⌫', 0, 'OK'].map(function (k) { return '<button' + (k === 'OK' ? ' class="ok"' : '') + ' data-k="' + k + '">' + (k === 'OK' ? T('gateOk') : k) + '</button>'; }).join('') +
    '</div></div></section>';
  wireGo();
  $$('.pad button').forEach(function (bt) {
    bt.onclick = function () {
      var k = bt.getAttribute('data-k');
      if (k === '⌫') ans = ans.slice(0, -1);
      else if (k === 'OK') { if (+ans === a * b) return go('parents', { tab: 'progress' }); toast(T('gateWrong')); setTimeout(function () { go('home'); }, 900); return; }
      else if (ans.length < 3) ans += k;
      $('#ans').textContent = ans;
    };
  });
};

SCREENS.parents = function (arg) {
  var tab = (arg && arg.tab) || 'progress';
  var body = tab === 'progress' ? progressHtml() : tab === 'settings' ? settingsHtml() : moreHtml();
  app.innerHTML = '<section class="screen">' + topBar(T('parents')) +
    '<div class="tabs">' + ['progress', 'settings', 'more'].map(function (t) { return '<button data-t="' + t + '" class="' + (t === tab ? 'on' : '') + '">' + T('p_' + t) + '</button>'; }).join('') + '</div>' +
    body + '</section>';
  wireGo();
  $$('.tabs button').forEach(function (b) { b.onclick = function () { go('parents', { tab: b.getAttribute('data-t') }); }; });
  if (tab === 'progress') wireProgress(); else if (tab === 'settings') wireSettings(); else wireMore();
};

function weakLetters() {
  return LETTERS.filter(function (d) { var s = stat(d.L); return s.qt >= 2 && s.qc / s.qt < 0.6; });
}
function progressHtml() {
  var learned = 0, watched = 0, traced = 0, qc = 0, qt = 0;
  LETTERS.forEach(function (d) { var s = stat(d.L); if (s.w) learned++; watched += s.w; if (s.t) traced++; qc += s.qc; qt += s.qt; });
  var weak = weakLetters().map(function (d) { return d.L; });
  var mins = S.day.d === today() ? Math.round(S.day.secs / 60) : 0;
  return '<div class="panel"><div class="kpis">' +
    '<div class="kpi"><b>' + learned + '/26</b><span>' + T('learned') + '</span></div>' +
    '<div class="kpi"><b>' + traced + '/26</b><span>' + T('traced') + '</span></div>' +
    '<div class="kpi"><b>' + (qt ? Math.round(qc / qt * 100) + '%' : '–') + '</b><span>' + T('quizAcc') + ' (' + qt + ')</span></div>' +
    '<div class="kpi"><b>' + S.stars + '</b><span>' + em('2b50') + ' ' + T('stars') + ' · ' + mins + ' ' + T('min') + '</span></div></div></div>' +
    '<div class="panel"><div class="lmap">' + LETTERS.map(function (d) {
      var s = stat(d.L), lv = (s.w && s.t && s.qc >= 2) ? 'l2' : (s.w || s.t || s.qt) ? 'l1' : '';
      return '<div class="' + lv + (weak.indexOf(d.L) >= 0 ? ' weak' : '') + '" title="' + d.L + ': watched ' + s.w + ', traced ' + s.t + ', quiz ' + s.qc + '/' + s.qt + '">' + d.L + '</div>';
    }).join('') + '</div>' +
    '<div class="legend"><span><i style="background:#eceff1"></i>not started</span><span><i style="background:#fff3c4"></i>started</span><span><i style="background:#c8f7c5"></i>watched + traced + quiz</span><span><i style="box-shadow:inset 0 0 0 2px #ff6b5b"></i>needs practice</span></div></div>' +
    '<div class="panel">' + (weak.length ? '<button class="btn b-quiz" id="weak" style="width:100%">' + T('practice') + ': ' + weak.join(' ') + '</button>' : '<p class="small">' + T('weakNone') + '</p>') + '</div>';
}
function wireProgress() {
  var w = $('#weak'); if (w) w.onclick = function () { go('quiz', { type: 'mix', only: weakLetters() }); };
}
function chips(key, vals) {
  return '<div class="chips">' + vals.map(function (v) { return '<button data-k="' + key + '" data-v="' + v[0] + '" class="' + (String(S.set[key]) === String(v[0]) ? 'on' : '') + '">' + v[1] + '</button>'; }).join('') + '</div>';
}
function settingsHtml() {
  return '<div class="panel">' +
    '<div class="set"><label>' + T('s_lang') + '</label>' + chips('lang', [['en', 'English'], ['bn', 'বাংলা']]) + '</div>' +
    '<div class="set"><label>' + T('s_speed') + '</label>' + chips('speed', [[0.75, '🐢 0.75'], [1, '1.0'], [1.25, '🐇 1.25']]) + '</div>' +
    '<div class="set"><label>' + T('s_sfx') + '</label><button class="toggle' + (S.set.sfx ? ' on' : '') + '" data-tg="sfx"></button></div>' +
    '<div class="set"><label>' + T('s_auto') + '</label><button class="toggle' + (S.set.auto ? ' on' : '') + '" data-tg="auto"></button></div>' +
    '<div class="set"><label>' + T('s_case') + '</label>' + chips('kase', [['both', T('c_both')], ['upper', T('c_upper')], ['lower', T('c_lower')]]) + '</div>' +
    '<div class="set"><label>' + T('s_opts') + '</label>' + chips('opts', [[3, '3'], [4, '4']]) + '</div>' +
    '<div class="set"><label>' + T('s_range') + '</label>' + chips('range', [['learned', T('r_learned')], ['ae', T('r_ae')], ['am', T('r_am')], ['all', T('r_all')]]) + '</div>' +
    '<div class="set"><label>' + T('s_limit') + '</label>' + chips('limit', [[0, T('off')], [15, '15 ' + T('min')], [30, '30 ' + T('min')], [60, '60 ' + T('min')]]) + '</div>' +
    '</div>';
}
function wireSettings() {
  $$('.chips button').forEach(function (b) {
    b.onclick = function () {
      var k = b.getAttribute('data-k'), v = b.getAttribute('data-v');
      S.set[k] = (k === 'lang' || k === 'range' || k === 'kase') ? v : +v; save();
      if (k === 'speed') say('Hello! A for Apple.');
      go('parents', { tab: 'settings' });
    };
  });
  $$('.toggle').forEach(function (b) { b.onclick = function () { var k = b.getAttribute('data-tg'); S.set[k] = !S.set[k]; save(); b.classList.toggle('on', S.set[k]); }; });
}
function moreHtml() {
  var billing = false; try { billing = window.AppBridge && AppBridge.hasBilling && AppBridge.hasBilling(); } catch (e) {}
  return '<div class="panel">' +
    '<button class="linkrow" id="yt">' + em('1f4fa') + T('youtube') + '</button>' +
    (billing ? '<button class="linkrow" id="sup">' + em('1f49d') + T('support') + '</button>' : '') +
    '<button class="linkrow" id="pp">' + em('1f512') + T('privacy') + '</button>' +
    '</div>' +
    '<div class="panel"><h3>' + T('about') + '</h3><p class="small">' + T('noAds') + '</p><p class="small">' + T('credits') + '</p><p class="small">Little Star Learning · v<span id="ver">1.0</span></p></div>' +
    '<div class="panel"><button class="parents-hold danger" id="rst" style="margin:0;width:100%"><div class="fill"></div><span>' + T('reset') + ' · ' + T('resetHold') + '</span></button></div>';
}
function openUrl(u) { try { if (window.AppBridge && AppBridge.openUrl) return AppBridge.openUrl(u); } catch (e) {} window.open(u, '_blank'); }
function wireMore() {
  $('#yt').onclick = function () { openUrl(CONFIG.youtubeUrl); };
  $('#pp').onclick = function () { openUrl(CONFIG.privacyUrl); };
  var sup = $('#sup'); if (sup) sup.onclick = function () { try { AppBridge.donate(); } catch (e) {} };
  try { if (window.AppBridge && AppBridge.version) $('#ver').textContent = AppBridge.version(); } catch (e) {}
  holdButton($('#rst'), 2000, function () { S.stars = 0; S.L = {}; save(); toast(T('resetDone')); go('parents', { tab: 'progress' }); });
}

SCREENS.sleepy = function () {
  app.innerHTML = '<section class="screen"><div class="result"><img class="bunny" src="img/bunny.webp" alt="" style="filter:saturate(.7)">' +
    '<h2>' + T('sleepy') + ' 😴</h2><p>' + T('sleepyT') + '</p>' +
    '<button class="parents-hold" id="ph"><div class="fill"></div><span>' + T('parents') + ' · ' + T('hold') + '</span></button></div></section>';
  holdButton($('#ph'), 2000, function () { go('gate'); });
  later(function () { say("I'm sleepy! Let's take a break. See you tomorrow!"); }, 400);
};

/* ---------- start ---------- */
document.documentElement.lang = S.set.lang;
document.addEventListener('visibilitychange', function () { if (document.hidden) { hush(); var v = app.querySelector('video'); if (v) v.pause(); } });
go('home');
