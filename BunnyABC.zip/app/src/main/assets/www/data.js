// BunnyABC content: one entry per letter.
// video: true  -> www/video/<l>.mp4 + www/img/poster/<l>.webp exist (made in Google Flow)
// video: false -> the app shows the animated "chalkboard card" until the video is added.
// To add a new letter video: drop f.mp4 into video/, f.webp into img/poster/, set video:true.
// words[].e = Twemoji file name in img/e/ ; end:true = the word ENDS with the letter (only for X)
// scene = suggested Google Flow scenery (see FLOW_PROMPTS.md)
var LETTERS = [
  { L:'A', video:true,  color:'#e53935', scene:'apple orchard meadow',
    words:[{w:'Apple',e:'1f34e'},{w:'Ant',e:'1f41c'}] },
  { L:'B', video:true,  color:'#1e88e5', scene:'playground picnic',
    words:[{w:'Ball',e:'26bd'},{w:'Banana',e:'1f34c'}] },
  { L:'C', video:true,  color:'#fb8c00', scene:'cosy pastel kitchen',
    words:[{w:'Cat',e:'1f431'},{w:'Cake',e:'1f382'}] },
  { L:'D', video:true,  color:'#6d4c41', scene:'lily pond with a log',
    words:[{w:'Dog',e:'1f436'},{w:'Duck',e:'1f986'}] },
  { L:'E', video:true,  color:'#8e24aa', scene:'jungle waterfall',
    words:[{w:'Elephant',e:'1f418'},{w:'Egg',e:'1f95a'}] },
  { L:'F', video:false, color:'#00897b', scene:'riverbank with lily pads',
    words:[{w:'Fish',e:'1f41f'},{w:'Frog',e:'1f438'}] },
  { L:'G', video:false, color:'#7cb342', scene:'savanna vineyard at sunset',
    words:[{w:'Giraffe',e:'1f992'},{w:'Grapes',e:'1f347'}] },
  { L:'H', video:false, color:'#d81b60', scene:'farm with red barn',
    words:[{w:'Horse',e:'1f434'},{w:'Hat',e:'1f452'}] },
  { L:'I', video:false, color:'#039be5', scene:'seaside ice-cream cart',
    words:[{w:'Ice cream',e:'1f366'},{w:'Iguana',e:'1f98e'}] },
  { L:'J', video:false, color:'#f4511e', scene:'breezy autumn park',
    words:[{w:'Juice',e:'1f9c3'},{w:'Jacket',e:'1f9e5'}] },
  { L:'K', video:false, color:'#3949ab', scene:'windy hilltop with outback rocks',
    words:[{w:'Kite',e:'1fa81'},{w:'Kangaroo',e:'1f998'}] },
  { L:'L', video:false, color:'#fdd835', scene:'sunny lemon grove',
    words:[{w:'Lion',e:'1f981'},{w:'Lemon',e:'1f34b'}] },
  { L:'M', video:false, color:'#43a047', scene:'tropical mango forest',
    words:[{w:'Monkey',e:'1f412'},{w:'Mango',e:'1f96d'}] },
  { L:'N', video:false, color:'#8d6e63', scene:'tall tree with a bird nest',
    words:[{w:'Nest',e:'1faba'},{w:'Nose',e:'1f443'}] },
  { L:'O', video:false, color:'#ff7043', scene:'moonlit orange orchard',
    words:[{w:'Owl',e:'1f989'},{w:'Orange',e:'1f34a'}] },
  { L:'P', video:false, color:'#00acc1', scene:'tropical beach',
    words:[{w:'Parrot',e:'1f99c'},{w:'Pineapple',e:'1f34d'}] },
  { L:'Q', video:false, color:'#ab47bc', scene:'fairy-tale castle garden',
    words:[{w:'Queen',e:'1f478'},{w:'Question',e:'2753'}] },
  { L:'R', video:false, color:'#ec407a', scene:'meadow after rain',
    words:[{w:'Rabbit',e:'1f407'},{w:'Rainbow',e:'1f308'}] },
  { L:'S', video:false, color:'#ffb300', scene:'sky from sunny day to starry night',
    words:[{w:'Sun',e:'2600'},{w:'Star',e:'2b50'}] },
  { L:'T', video:false, color:'#ef6c00', scene:'vegetable garden by the jungle',
    words:[{w:'Tiger',e:'1f42f'},{w:'Tomato',e:'1f345'}] },
  { L:'U', video:false, color:'#5e35b1', scene:'magical rainy meadow',
    words:[{w:'Umbrella',e:'2602'},{w:'Unicorn',e:'1f984'}] },
  { L:'V', video:false, color:'#c62828', scene:'village road with a music stage',
    words:[{w:'Violin',e:'1f3bb'},{w:'Van',e:'1f690'}] },
  { L:'W', video:false, color:'#2e7d32', scene:'beach with whale in the sea',
    words:[{w:'Watermelon',e:'1f349'},{w:'Whale',e:'1f433'}] },
  { L:'X', video:false, color:'#546e7a', scene:'friendly clinic room',
    words:[{w:'X-ray',e:'1fa7b'},{w:'Fox',e:'1f98a',end:true}] },
  { L:'Y', video:false, color:'#f9a825', scene:'cosy knitting corner',
    words:[{w:'Yo-yo',e:'1fa80'},{w:'Yarn',e:'1f9f6'}] },
  { L:'Z', video:false, color:'#212121', scene:'zoo gate with number signs',
    words:[{w:'Zebra',e:'1f993'},{w:'Zero',e:'30-20e3'}] }
];

// UI strings (spoken prompts stay English because the child is learning English letters)
var STR = {
  en: {
    title:'Bunny ABC', hello:"Hello! Let's learn A B C!", learn:'Learn A–Z', quiz:'Play Quiz', trace:'Trace', watchAll:'Watch All',
    parents:'For parents', hold:'Hold 2 seconds', stars:'stars',
    chooseGame:'Choose a game', q_listen:'Listen & Find', q_starts:'Starts With', q_picture:'Picture Match',
    q_case:'Big & Small', q_missing:'Missing Letter', q_mix:'Surprise Mix',
    q_listen_d:'Hear a letter, tap it', q_starts_d:'Which letter does it start with?', q_picture_d:'Find the picture',
    q_case_d:'Match A with a', q_missing_d:'A _ C', q_mix_d:'All games mixed',
    great:'Great job!', tryAgain:'Try again', playAgain:'Play again', home:'Home', next:'Next',
    youGot:'You got', of:'of', soon:'Video coming soon', traceHint:'Trace the letter with your finger',
    clear:'Clear', upper:'ABC', lower:'abc', wellDone:'Well done!',
    gateQ:'Grown-ups only: what is', gateOk:'OK', gateWrong:'Not quite – ask a grown-up',
    p_progress:'Progress', p_settings:'Settings', p_more:'More', learned:'Letters learned',
    watched:'Videos watched', quizAcc:'Quiz accuracy', traced:'Letters traced', practice:'Practise weak letters',
    s_lang:'App language', s_speed:'Voice speed', s_sfx:'Sound effects', s_opts:'Answer choices',
    s_range:'Letters in quizzes', r_learned:'Only letters seen', r_ae:'A–E', r_am:'A–M', r_all:'A–Z',
    s_case:'Letters shown as', c_both:'Aa', c_upper:'A', c_lower:'a', s_auto:'Play next video automatically',
    s_limit:'Daily play time', off:'Off', min:'min', youtube:'Our YouTube channel', privacy:'Privacy policy',
    support:'Support Bunny ABC', about:'About', reset:'Reset progress', resetHold:'Hold to reset',
    resetDone:'Progress cleared', sleepy:'Bunny is sleepy!', sleepyT:'Time for a break. See you tomorrow!',
    back:'Back', weakNone:'No weak letters yet – keep playing!', letter:'Letter',
    credits:'Videos made with Google Flow. Emoji art: Twemoji (CC-BY 4.0). Font: Fredoka (OFL).',
    noAds:'No ads in learning screens. No personal data collected.'
  },
  bn: {
    title:'বানি এবিসি', hello:'হ্যালো! চলো A B C শিখি!', learn:'A–Z শিখি', quiz:'কুইজ খেলি', trace:'লিখি', watchAll:'সব দেখি',
    parents:'অভিভাবকদের জন্য', hold:'২ সেকেন্ড চেপে ধরুন', stars:'তারা',
    chooseGame:'একটা খেলা বেছে নাও', q_listen:'শুনে খুঁজি', q_starts:'কোন অক্ষর দিয়ে শুরু', q_picture:'ছবি মেলাই',
    q_case:'বড় আর ছোট', q_missing:'হারানো অক্ষর', q_mix:'চমক মিক্স',
    q_listen_d:'অক্ষর শুনে ট্যাপ করো', q_starts_d:'ছবির নাম কোন অক্ষরে শুরু?', q_picture_d:'ঠিক ছবিটা খোঁজো',
    q_case_d:'A এর সাথে a মেলাও', q_missing_d:'A _ C', q_mix_d:'সব খেলা একসাথে',
    great:'দারুণ!', tryAgain:'আবার চেষ্টা করো', playAgain:'আবার খেলি', home:'হোম', next:'পরের',
    youGot:'তুমি পেয়েছ', of:'এর মধ্যে', soon:'ভিডিও শীঘ্রই আসছে', traceHint:'আঙুল দিয়ে অক্ষরের উপর লেখো',
    clear:'মুছি', upper:'ABC', lower:'abc', wellDone:'খুব ভালো!',
    gateQ:'শুধু বড়দের জন্য: কত হয়', gateOk:'ঠিক আছে', gateWrong:'হয়নি – বড় কাউকে ডাকো',
    p_progress:'অগ্রগতি', p_settings:'সেটিংস', p_more:'আরও', learned:'শেখা অক্ষর',
    watched:'দেখা ভিডিও', quizAcc:'কুইজে সঠিক', traced:'লেখা অক্ষর', practice:'দুর্বল অক্ষর অনুশীলন',
    s_lang:'অ্যাপের ভাষা', s_speed:'কণ্ঠের গতি', s_sfx:'সাউন্ড ইফেক্ট', s_opts:'উত্তরের অপশন',
    s_range:'কুইজের অক্ষর', r_learned:'শুধু দেখা অক্ষর', r_ae:'A–E', r_am:'A–M', r_all:'A–Z',
    s_case:'অক্ষর দেখাবে', c_both:'Aa', c_upper:'A', c_lower:'a', s_auto:'পরের ভিডিও নিজে চলবে',
    s_limit:'দৈনিক খেলার সময়', off:'বন্ধ', min:'মিনিট', youtube:'আমাদের ইউটিউব চ্যানেল', privacy:'প্রাইভেসি পলিসি',
    support:'বানি এবিসি-কে সাপোর্ট করুন', about:'সম্পর্কে', reset:'অগ্রগতি মুছুন', resetHold:'চেপে ধরে মুছুন',
    resetDone:'অগ্রগতি মুছে ফেলা হয়েছে', sleepy:'বানির ঘুম পেয়েছে!', sleepyT:'এখন বিরতি। কাল আবার দেখা হবে!',
    back:'ফিরে যাই', weakNone:'এখনও কোনো দুর্বল অক্ষর নেই – খেলতে থাকো!', letter:'অক্ষর',
    credits:'ভিডিও Google Flow দিয়ে তৈরি। ইমোজি: Twemoji (CC-BY 4.0)। ফন্ট: Fredoka (OFL)।',
    noAds:'শেখার স্ক্রিনে কোনো বিজ্ঞাপন নেই। কোনো ব্যক্তিগত তথ্য নেওয়া হয় না।'
  }
};

var CONFIG = {
  youtubeUrl: 'https://www.youtube.com/',            // TODO: put your channel link here
  privacyUrl: 'https://debaphp.github.io/thebasement/privacy.html'
};
