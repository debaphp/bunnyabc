package com.purnota.abc;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.webkit.JavascriptInterface;

import java.util.Locale;
import java.util.Set;

/* Reads letters, words and quiz questions aloud in English using the phone's TTS engine. */
public class TtsBridge implements TextToSpeech.OnInitListener {

    private final TextToSpeech tts;
    private boolean ready = false;

    public TtsBridge(Context ctx) {
        tts = new TextToSpeech(ctx.getApplicationContext(), this);
    }

    @Override
    public void onInit(int status) {
        if (status != TextToSpeech.SUCCESS) return;
        int r = tts.setLanguage(Locale.US);
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts.setLanguage(Locale.ENGLISH);
        }
        pickOfflineVoice();
        tts.setPitch(1.1f);
        ready = true;
    }

    /* Prefer a good offline English voice so speech works without internet. */
    private void pickOfflineVoice() {
        try {
            Set<Voice> voices = tts.getVoices();
            if (voices == null) return;
            Voice best = null;
            for (Voice v : voices) {
                if (v.getLocale() == null || !"en".equals(v.getLocale().getLanguage())) continue;
                if (v.isNetworkConnectionRequired()) continue;
                if (v.getFeatures() != null && v.getFeatures().contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)) continue;
                boolean us = "US".equals(v.getLocale().getCountry());
                if (best == null
                        || (us && !"US".equals(best.getLocale().getCountry()))
                        || (us == "US".equals(best.getLocale().getCountry()) && v.getQuality() > best.getQuality())) {
                    best = v;
                }
            }
            if (best != null) tts.setVoice(best);
        } catch (Exception ignored) { }
    }

    @JavascriptInterface
    public void speak(String text, double rate) {
        if (!ready || text == null) return;
        tts.setSpeechRate((float) (0.85 * rate));
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "bunny");
    }

    @JavascriptInterface
    public void stop() {
        if (ready) tts.stop();
    }

    public void shutdown() {
        tts.stop();
        tts.shutdown();
    }
}
