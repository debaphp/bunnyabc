package com.purnota.abc;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.telephony.TelephonyManager;
import android.webkit.JavascriptInterface;

import java.util.Locale;

/* Small helpers for the web app. Links only open from the parent-gated screen. */
public class AppBridge {

    private final Activity act;

    public AppBridge(Activity act) {
        this.act = act;
    }

    @JavascriptInterface
    public void openUrl(final String url) {
        if (url == null || !url.startsWith("https://")) return;
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    act.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception ignored) { }
            }
        });
    }

    @JavascriptInterface
    @SuppressWarnings("deprecation")
    public void vibrate(int ms) {
        try {
            Vibrator v = (Vibrator) act.getSystemService(Context.VIBRATOR_SERVICE);
            if (v == null || !v.hasVibrator()) return;
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
            else v.vibrate(ms);
        } catch (Exception ignored) { }
    }

    @JavascriptInterface
    public String version() {
        try {
            PackageInfo p = act.getPackageManager().getPackageInfo(act.getPackageName(), 0);
            return p.versionName;
        } catch (Exception e) {
            return "1.0";
        }
    }

    /* SIM country first, then phone region – used only to pick Bengali or English on first launch. */
    @JavascriptInterface
    public String country() {
        try {
            TelephonyManager tm = (TelephonyManager) act.getSystemService(Context.TELEPHONY_SERVICE);
            if (tm != null) {
                String c = tm.getSimCountryIso();
                if (c != null && c.length() == 2) return c.toUpperCase(Locale.US);
            }
        } catch (Exception ignored) { }
        return Locale.getDefault().getCountry().toUpperCase(Locale.US);
    }

    /* Donations: copy BillingBridge from MathFairy later and return true here. */
    @JavascriptInterface
    public boolean hasBilling() {
        return false;
    }

    @JavascriptInterface
    public void donate() { }
}
