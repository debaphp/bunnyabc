# Bunny ABC – A to Z with the Bunny Teacher

Android app (ages 3–6). Same pattern as MathFairy: HTML/JS/CSS in `app/src/main/assets/www`, shown in a WebView, plus small Java bridges.

- **Package:** `com.purnota.abc` (change it in `app/build.gradle` **before** the first Play upload, if you want a different one)
- **Fully offline:** no INTERNET permission, no ads, no analytics. Progress is saved on the phone only.
- **Version:** 1.0 (versionCode 1)

## What is inside
| Part | What it does |
|---|---|
| Learn A–Z | 26-letter grid. A–E play your Flow videos; F–Z show an animated chalkboard card (bunny + letter + 2 words, read aloud) until their video is added |
| Watch All | Plays every letter in a row (videos and chalkboard cards) |
| Quiz (6 games) | Listen & Find · Starts With (picture → letter) · Picture Match (letter → picture) · Big & Small (A ↔ a) · Missing Letter (A _ C) · Surprise Mix. 10 questions per round, stars for right first tries |
| Trace | Finger-tracing for big and small letters. Checks that the child covered the letter and did not just scribble |
| For parents | Hold 2 s, then a times-table question. **Progress** (letters learned/traced, quiz accuracy, letter map, "practise weak letters"), **Settings** (English/বাংলা, voice speed, sound effects, autoplay, Aa/A/a, 3 or 4 answers, which letters appear in quizzes, daily time limit 15/30/60 min), **More** (YouTube channel, privacy policy, reset progress) |

## Adding the next videos (F–Z)
1. Make the video in Google Flow (prompts in `FLOW_PROMPTS.md` – same words the app already uses).
2. Run `tools/add_video.sh F F.mp4` → compresses it, makes the thumbnail, and sets `video:true` in `data.js`.
   No ffmpeg? Send the videos to Claude and ask to add them.
3. Raise `versionCode` / `versionName` in `app/build.gradle`, upload, build.

Video compression: H.264 480p, CRF 28, x264 `veryslow` + `tune animation`, mono AAC 64 kbps, faststart.
A–E went from 19.6 MB to 4.8 MB (about 75 % smaller). All 26 letters should be about 25 MB.
H.264 was chosen over AV1/VP9 because every Android phone decodes it in hardware (smooth on cheap phones, less battery). AV1 was only about 20 % smaller.

## Build (GitHub Actions)
1. New **private** repo, e.g. `debaphp/bunny-abc`. Upload all files from this folder (or upload `BunnyABC.zip` together with `.github/workflows/build.yml`).
2. Add the repo secrets `ONKO_KEYSTORE_BASE64`, `ONKO_KEY_PASSWORD`, `ONKO_KEY_ALIAS` (same values as MathFairy – one upload key can sign several apps). Never commit the key file.
3. Actions → *Build Bunny ABC* → artifacts: `bunny-abc.apk` (test) and `bunny-abc-play-store` (.aab).

## Later
- Donations: copy `BillingBridge` from MathFairy and make `AppBridge.hasBilling()` return true – the "Support" row appears in For parents → More.
- Set your YouTube channel link in `www/data.js` → `CONFIG.youtubeUrl`.

Credits: emoji art Twemoji (CC-BY 4.0), font Fredoka (SIL OFL, see `www/font/`).
