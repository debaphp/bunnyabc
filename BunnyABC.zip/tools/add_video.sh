#!/bin/bash
# Compress a Google Flow letter video for Bunny ABC and switch that letter to "video" in data.js.
# Usage:  tools/add_video.sh F  /path/to/F.mp4
# Needs ffmpeg. Settings = the ones used for A–E (H.264 480p, CRF 28, veryslow, animation tune, mono AAC 64k).
set -e
L=$(echo "$1" | tr a-z A-Z); l=$(echo "$L" | tr A-Z a-z); IN="$2"
[ -z "$L" ] || [ ! -f "$IN" ] && { echo "Usage: $0 LETTER input.mp4"; exit 1; }
W="$(dirname "$0")/../app/src/main/assets/www"
ffmpeg -v error -y -i "$IN" -vf scale=854:480:flags=lanczos -c:v libx264 -preset veryslow -tune animation -crf 28 \
  -profile:v high -level 3.1 -pix_fmt yuv420p -g 48 -c:a aac -b:a 64k -ac 1 -movflags +faststart "$W/video/$l.mp4"
DUR=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$IN")
SS=$(python3 -c "print(max(0, float('$DUR') - 0.4))")
ffmpeg -v error -y -ss "$SS" -i "$IN" -frames:v 1 -vf scale=480:-1 -c:v libwebp -quality 70 "$W/img/poster/$l.webp"
sed -i "s/{ L:'$L', video:false/{ L:'$L', video:true /" "$W/data.js"
echo "$L done: $(du -h "$W/video/$l.mp4" | cut -f1)  (data.js updated)"
