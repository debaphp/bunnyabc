# Google Flow prompts – Bunny ABC (F–Z)

Keep every clip **8 seconds, 16:9, 720p**, same teacher as A–E. The app already uses these exact words, so the video and the quiz will match.

**Character block (paste at the start of every prompt):**
> A cute fluffy white bunny teacher with big pink ears, round gold glasses and a striped orange-and-yellow bow tie, standing beside a wooden easel with a green chalkboard. Bright, soft 3D animated kids-cartoon style, cheerful, gentle camera.

## F — Fish / Frog
> [Character block] Scene: riverbank with lily pads. The bunny writes "Ff" on the chalkboard, then writes "F FOR FISH", then "F FOR FROG" below it. A friendly cartoon fish appears next to the board, then a friendly cartoon frog. The bunny points at each and says: "F! F for Fish! F for Frog!" Sparkles at the end.

## G — Giraffe / Grapes
> [Character block] Scene: savanna vineyard at sunset. The bunny writes "Gg" on the chalkboard, then writes "G FOR GIRAFFE", then "G FOR GRAPES" below it. A friendly cartoon giraffe appears next to the board, then a friendly cartoon grapes. The bunny points at each and says: "G! G for Giraffe! G for Grapes!" Sparkles at the end.

## H — Horse / Hat
> [Character block] Scene: farm with red barn. The bunny writes "Hh" on the chalkboard, then writes "H FOR HORSE", then "H FOR HAT" below it. A friendly cartoon horse appears next to the board, then a friendly cartoon hat. The bunny points at each and says: "H! H for Horse! H for Hat!" Sparkles at the end.

## I — Ice cream / Iguana
> [Character block] Scene: seaside ice-cream cart. The bunny writes "Ii" on the chalkboard, then writes "I FOR ICE CREAM", then "I FOR IGUANA" below it. A friendly cartoon ice cream appears next to the board, then a friendly cartoon iguana. The bunny points at each and says: "I! I for Ice cream! I for Iguana!" Sparkles at the end.

## J — Juice / Jacket
> [Character block] Scene: breezy autumn park. The bunny writes "Jj" on the chalkboard, then writes "J FOR JUICE", then "J FOR JACKET" below it. A friendly cartoon juice appears next to the board, then a friendly cartoon jacket. The bunny points at each and says: "J! J for Juice! J for Jacket!" Sparkles at the end.

## K — Kite / Kangaroo
> [Character block] Scene: windy hilltop with outback rocks. The bunny writes "Kk" on the chalkboard, then writes "K FOR KITE", then "K FOR KANGAROO" below it. A friendly cartoon kite appears next to the board, then a friendly cartoon kangaroo. The bunny points at each and says: "K! K for Kite! K for Kangaroo!" Sparkles at the end.

## L — Lion / Lemon
> [Character block] Scene: sunny lemon grove. The bunny writes "Ll" on the chalkboard, then writes "L FOR LION", then "L FOR LEMON" below it. A friendly cartoon lion appears next to the board, then a friendly cartoon lemon. The bunny points at each and says: "L! L for Lion! L for Lemon!" Sparkles at the end.

## M — Monkey / Mango
> [Character block] Scene: tropical mango forest. The bunny writes "Mm" on the chalkboard, then writes "M FOR MONKEY", then "M FOR MANGO" below it. A friendly cartoon monkey appears next to the board, then a friendly cartoon mango. The bunny points at each and says: "M! M for Monkey! M for Mango!" Sparkles at the end.

## N — Nest / Nose
> [Character block] Scene: tall tree with a bird nest. The bunny writes "Nn" on the chalkboard, then writes "N FOR NEST", then "N FOR NOSE" below it. A friendly cartoon nest appears next to the board, then a friendly cartoon nose. The bunny points at each and says: "N! N for Nest! N for Nose!" Sparkles at the end.

## O — Owl / Orange
> [Character block] Scene: moonlit orange orchard. The bunny writes "Oo" on the chalkboard, then writes "O FOR OWL", then "O FOR ORANGE" below it. A friendly cartoon owl appears next to the board, then a friendly cartoon orange. The bunny points at each and says: "O! O for Owl! O for Orange!" Sparkles at the end.

## P — Parrot / Pineapple
> [Character block] Scene: tropical beach. The bunny writes "Pp" on the chalkboard, then writes "P FOR PARROT", then "P FOR PINEAPPLE" below it. A friendly cartoon parrot appears next to the board, then a friendly cartoon pineapple. The bunny points at each and says: "P! P for Parrot! P for Pineapple!" Sparkles at the end.

## Q — Queen / Question
> [Character block] Scene: fairy-tale castle garden. The bunny writes "Qq" on the chalkboard, then writes "Q FOR QUEEN", then "Q FOR QUESTION" below it. A friendly cartoon queen appears next to the board, then a friendly cartoon question. The bunny points at each and says: "Q! Q for Queen! Q for Question!" Sparkles at the end.

## R — Rabbit / Rainbow
> [Character block] Scene: meadow after rain. The bunny writes "Rr" on the chalkboard, then writes "R FOR RABBIT", then "R FOR RAINBOW" below it. A friendly cartoon rabbit appears next to the board, then a friendly cartoon rainbow. The bunny points at each and says: "R! R for Rabbit! R for Rainbow!" Sparkles at the end.

## S — Sun / Star
> [Character block] Scene: sky from sunny day to starry night. The bunny writes "Ss" on the chalkboard, then writes "S FOR SUN", then "S FOR STAR" below it. A friendly cartoon sun appears next to the board, then a friendly cartoon star. The bunny points at each and says: "S! S for Sun! S for Star!" Sparkles at the end.

## T — Tiger / Tomato
> [Character block] Scene: vegetable garden by the jungle. The bunny writes "Tt" on the chalkboard, then writes "T FOR TIGER", then "T FOR TOMATO" below it. A friendly cartoon tiger appears next to the board, then a friendly cartoon tomato. The bunny points at each and says: "T! T for Tiger! T for Tomato!" Sparkles at the end.

## U — Umbrella / Unicorn
> [Character block] Scene: magical rainy meadow. The bunny writes "Uu" on the chalkboard, then writes "U FOR UMBRELLA", then "U FOR UNICORN" below it. A friendly cartoon umbrella appears next to the board, then a friendly cartoon unicorn. The bunny points at each and says: "U! U for Umbrella! U for Unicorn!" Sparkles at the end.

## V — Violin / Van
> [Character block] Scene: village road with a music stage. The bunny writes "Vv" on the chalkboard, then writes "V FOR VIOLIN", then "V FOR VAN" below it. A friendly cartoon violin appears next to the board, then a friendly cartoon van. The bunny points at each and says: "V! V for Violin! V for Van!" Sparkles at the end.

## W — Watermelon / Whale
> [Character block] Scene: beach with whale in the sea. The bunny writes "Ww" on the chalkboard, then writes "W FOR WATERMELON", then "W FOR WHALE" below it. A friendly cartoon watermelon appears next to the board, then a friendly cartoon whale. The bunny points at each and says: "W! W for Watermelon! W for Whale!" Sparkles at the end.

## X — X-ray / Fox
> [Character block] Scene: friendly clinic room. The bunny writes "Xx" on the chalkboard, then writes "X FOR X-RAY", then "FOX" (point at the last letter X) below it. A friendly cartoon x-ray appears next to the board, then a friendly cartoon fox. The bunny points at each and says: "X! X for X-ray! Fox ends with X!" Sparkles at the end.

## Y — Yo-yo / Yarn
> [Character block] Scene: cosy knitting corner. The bunny writes "Yy" on the chalkboard, then writes "Y FOR YO-YO", then "Y FOR YARN" below it. A friendly cartoon yo-yo appears next to the board, then a friendly cartoon yarn. The bunny points at each and says: "Y! Y for Yo-yo! Y for Yarn!" Sparkles at the end.

## Z — Zebra / Zero
> [Character block] Scene: zoo gate with number signs. The bunny writes "Zz" on the chalkboard, then writes "Z FOR ZEBRA", then "Z FOR ZERO" below it. A friendly cartoon zebra appears next to the board, then a friendly cartoon zero. The bunny points at each and says: "Z! Z for Zebra! Z for Zero!" Sparkles at the end.

